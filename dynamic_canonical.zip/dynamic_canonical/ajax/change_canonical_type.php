<?php
require_once('../../../../wp-load.php');
get_header();

global $wpdb;

$table_name = $wpdb->prefix . 'dynamic_canonical';

$data = array(
    'host_type' => $_POST['host_type']
);

$where = array(
    'id' => 1, // Replace with your record ID
);

$wpdb->update($table_name, $data, $where);

?>