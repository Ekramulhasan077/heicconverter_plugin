<?php
/*
Plugin Name: Dynamic Canonical
Description:  Easily manage and customize your canonical links with the Dynamic Canonical plugin. This user-friendly tool allows you to set dynamic canonical URLs for your posts and pages while offering the flexibility to manually configure settings for HTTP, HTTPS, WWW, and more. Enhance your SEO strategy and ensure search engines index the right pages with ease!
Version: 1.0.3
Author: Md Turjo
Author URI: https://www.facebook.com/tarikulislambd.me
*/


// Hook to modify the <head> section
add_action('wp_head', 'add_title_and_canonical_to_head');

function add_title_and_canonical_to_head() {
    if (is_single() || is_page()) {
        global $wpdb;
        $table_name = $wpdb->prefix . 'dynamic_canonical';
        $settings_data = $wpdb->get_row("SELECT * FROM $table_name WHERE id=1");
        $canonical_url = get_permalink();
        $url = preg_replace('/^(https?:\/\/)?(www\.)?/', '', $canonical_url);
        echo '<link rel="canonical" href="' . $settings_data->host_type . $url . '" />';
    }
}

// Add settings page to the admin menu
add_action('admin_menu', 'custom_plugin_menu');

function custom_plugin_menu() {
    add_menu_page(
        'Plugin Settings', // Page title
        'Title Header Settings', // Menu title
        'manage_options', // Capability
        'title-header-settings', // Menu slug
        'custom_plugin_settings_page' // Callback function
    );
}

// Display the settings page
function custom_plugin_settings_page() {
    global $wpdb;
    $table_name = $wpdb->prefix . 'dynamic_canonical';
    $settings_data = $wpdb->get_row("SELECT * FROM $table_name WHERE id=1");
    ?>
    <div class="wrap" style="font-size: large; font-weight: 700;">
        <h1>Settings</h1>
        <div  style="display: grid;">
            <label for="type_one" class="d-flex" style="margin-top: 20px;">
            <input type="radio" name="canonical_type" value="http://" id="type_one" <?php if($settings_data->host_type == "http://"){echo 'checked';} ?>>
            http://
            </label>
            <label for="type_two" class="d-flex" style="margin-top: 20px;">
            <input type="radio" name="canonical_type" value="http://www." id="type_two" <?php if($settings_data->host_type == "http://www."){echo 'checked';} ?>>
            http://www
            </label>
            <label for="type_three" class="d-flex" style="margin-top: 20px;">
            <input type="radio" name="canonical_type" value="https://" id="type_three" <?php if($settings_data->host_type == "https://"){echo 'checked';} ?>>
            https://
            </label>
            <label for="type_four" class="d-flex" style="margin-top: 20px;">
            <input type="radio" name="canonical_type" value="https://www." id="type_four" <?php if($settings_data->host_type == "https://www."){echo 'checked';} ?>>
            https://www
            </label>
        </div>
        <div class="d-flex" style="margin-top: 20px; color: green;">
            <span id="display_canonical_type"><?php echo $settings_data->host_type ?></span><span>heicconverter.com/dynamic-canonical-link</span>
        </div>
        <script type="text/javascript">
        document.addEventListener('DOMContentLoaded', function() {
            // Get all radio buttons
            var radioButtons = document.querySelectorAll('input[name="canonical_type"]');
            
            // Add event listener for 'change' event
            radioButtons.forEach(function(radio) {
                radio.addEventListener('change', function() {
                    // Perform action when radio button value changes
                    var selectedValue = this.value;
                    document.getElementById('display_canonical_type').innerText = selectedValue;
                    
                    insertRecord(selectedValue);
                });
            });
        });

        function insertRecord(hostType) {
    const formData = new FormData();
    formData.append('host_type', hostType);

    const xhr = new XMLHttpRequest();
    xhr.open('POST', '../wp-content/plugins/dynamic_canonical/ajax/change_canonical_type.php', true);

    xhr.onload = function () {
        if (xhr.status === 200) {
            alert("Ok");
        }
    };

    xhr.send(formData);
}
        </script>
    </div>

    <?php
}

// Add a settings link next to Deactivate button on the plugins page
add_filter('plugin_action_links_' . plugin_basename(__FILE__), 'custom_plugin_action_links');

function custom_plugin_action_links($links) {
    $settings_link = '<a href="admin.php?page=title-header-settings">Settings</a>';
    array_unshift($links, $settings_link); // Add the settings link to the beginning of the links array
    return $links;
}



function create_converter_table()
{
    global $wpdb;
    $table_name = $wpdb->prefix . 'dynamic_canonical';

    $charset_collate = $wpdb->get_charset_collate();

    $sql = "CREATE TABLE $table_name (
        host_type text,
        host_name text
    ) $charset_collate;";

    require_once (ABSPATH . 'wp-admin/includes/upgrade.php');
    dbDelta($sql);


    $counter_data = $wpdb->get_row("SELECT COUNT(*) AS count FROM $table_name");
    if ($counter_data->count == 0) {
        $data = array(
            array('host_type' => 'http', 'host_name' => 'domain'),
            
        );

        foreach ($data as $row) {
            $wpdb->insert($table_name, $row);
        }
    }
}

function create_all_tables()
{
    create_converter_table();
}
// Hook the function to create the custom table to the plugin activation hook
register_activation_hook(__FILE__, 'create_all_tables');