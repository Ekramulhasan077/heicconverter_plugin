
alert("turjo");

var radioButtons = document.querySelectorAll('input[name="canonical_type"]');

// Add event listener for 'change' event
radioButtons.forEach(function (radio) {
    radio.addEventListener('change', function () {
        // Perform action when radio button value changes
        var selectedValue = this.value;
        document.getElementById('display_canonical_type').innerText = "You selected: " + selectedValue;

        // Additional action: send value to server using AJAX (optional)
        // You can implement an AJAX call here if needed
    });
});



function insertRecord(fileName, fileType) {
    const formData = new FormData();
    formData.append('file_name', fileName);
    formData.append('file_type', fileType);

    const xhr = new XMLHttpRequest();
    xhr.open('POST', '../wp-content/plugins/dynamic_canonical/ajax/change_canonical_type.php', true);

    xhr.onload = function () {

    };

    xhr.send(formData);
}